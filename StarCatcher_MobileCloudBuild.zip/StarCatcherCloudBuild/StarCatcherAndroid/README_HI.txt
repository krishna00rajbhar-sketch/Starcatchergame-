स्टार कैचर Android प्रोजेक्ट (हिंदी निर्देश)

यह Android Studio प्रोजेक्ट आपके HTML गेम को WebView के अंदर चलाता है।
गेम की मुख्य सुविधाएँ ऑफ़लाइन चलती हैं। वेबसाइट/YouTube प्रमोशन लिंक खोलने के लिए इंटरनेट चाहिए।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को Extract करके StarCatcher फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें। ज़रूरत पड़ने पर Android SDK Platform 35 इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
6. APK अपने फ़ोन में भेजें और इंस्टॉल करें। फ़ोन आपसे इस स्रोत से ऐप इंस्टॉल करने की अनुमति माँग सकता है।

ध्यान दें:
- यह Android Studio प्रोजेक्ट है, तैयार APK नहीं। इस वातावरण में Android SDK/Gradle build उपलब्ध नहीं था, इसलिए APK compile करके जाँचा नहीं गया।
- Play Store पर डालने के लिए debug APK के बजाय signed release AAB बनाना, Play Console अकाउंट और Google की मौजूदा नीतियाँ पूरी करना ज़रूरी हो सकता है।
- ऐप का applicationId अभी com.example.starcatcher है; प्रकाशित करने से पहले इसे अपने अनोखे पैकेज नाम में बदलें।
