Star Catcher — मोबाइल से APK बनाने की अतिरिक्त विधि

यह ZIP खुद APK नहीं है। इसमें GitHub Actions के लिए workflow जोड़ा गया है, जो GitHub पर प्रोजेक्ट अपलोड होने के बाद APK बनाने की कोशिश करेगा।

ज़रूरी:
- GitHub अकाउंट और इंटरनेट चाहिए।
- GitHub की वेबसाइट पर नया repository बनाएँ।
- ZIP को अपने फ़ोन में Extract करें। फिर प्रोजेक्ट के अंदर की सभी फ़ाइलें/फ़ोल्डर repository में अपलोड करें, खासकर .github/workflows/build-apk.yml फ़ाइल सहित।
- Repository की Actions टैब में “Build Star Catcher APK” workflow चुनें और Run workflow दबाएँ (या main branch पर push/commit करें)।
- Build सफल होने पर workflow run खोलें और Artifacts में StarCatcher-debug-APK डाउनलोड करें। ZIP artifact के अंदर app-debug.apk होगा।
- APK केवल परीक्षण के लिए debug APK है, Play Store पर प्रकाशित करने वाला signed release नहीं।

नोट: GitHub UI मोबाइल पर folders और .github जैसे hidden folders अपलोड करने में कठिन हो सकता है। यदि अटकें, स्क्रीनशॉट भेजें। Build असफल हो सकता है; error log देखकर ठीक करना पड़ेगा।
